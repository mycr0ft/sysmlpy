#!/usr/bin/env python3
"""
Automated test script for sysml2py behavioral modeling bugs

Run this to reproduce both issues:
1. State machine parsing crash
2. Activity parameter/action extraction failure
"""

import sys

try:
    from sysml2py import loads
    print("✓ sysml2py imported successfully")
    print()
except ImportError:
    print("✗ ERROR: sysml2py not installed")
    print("Install with: pip install sysml2py")
    sys.exit(1)

print("=" * 70)
print("Issue 1: State Machine Parsing Crash")
print("=" * 70)
print()

# Test 1: State Machine Crash
state_machine_sysml = """
package MinimalStateMachineTest {
    state def SimpleSM {
        state stateA;
        state stateB;
        
        transition a_to_b
            first stateA
            then stateB;
    }
}
"""

print("SysML Model:")
print(state_machine_sysml)
print()

try:
    model = loads(state_machine_sysml)
    print("✓ SUCCESS: Model loaded without crashing")
    print("   (Bug may be fixed!)")
except AttributeError as e:
    print(f"✗ CRASH: {e}")
    print()
    print("   Expected error: 'BehaviorUsageMember' object has no attribute 'get_definition'")
    if "BehaviorUsageMember" in str(e) and "get_definition" in str(e):
        print("   ✓ Error matches expected bug")
    else:
        print("   ⚠️  Different error than expected")
except Exception as e:
    print(f"✗ UNEXPECTED ERROR: {e}")

print()
print("=" * 70)
print("Issue 2: Activity Parameter/Action Extraction")
print("=" * 70)
print()

# Test 2: Activity Extraction
activity_sysml = """
package MinimalActivityTest {
    action def SimpleActivity {
        in inputParam : Real;
        out outputParam : Boolean;
        
        action stepOne {
            in data : Real;
        }
        
        action stepTwo {
            out result : Boolean;
        }
    }
}
"""

print("SysML Model:")
print(activity_sysml)
print()

try:
    model = loads(activity_sysml)
    print("✓ Model loads without crashing")
    print()
    
    action = model.packages[0].actions[0]
    print(f"Action found: {action.name}")
    print()
    
    # Check inputs
    expected_inputs = 1
    actual_inputs = len(action.action_inputs)
    print(f"Inputs:")
    print(f"  Expected: {expected_inputs} (inputParam)")
    print(f"  Actual:   {actual_inputs}")
    if actual_inputs == expected_inputs:
        print("  ✓ PASS: Inputs extracted correctly")
    else:
        print("  ✗ FAIL: Inputs not extracted")
    print()
    
    # Check outputs
    expected_outputs = 1
    actual_outputs = len(action.action_outputs)
    print(f"Outputs:")
    print(f"  Expected: {expected_outputs} (outputParam)")
    print(f"  Actual:   {actual_outputs}")
    if actual_outputs == expected_outputs:
        print("  ✓ PASS: Outputs extracted correctly")
    else:
        print("  ✗ FAIL: Outputs not extracted")
    print()
    
    # Check nested actions
    expected_actions = 2
    actual_actions = len(action.actions)
    print(f"Nested Actions:")
    print(f"  Expected: {expected_actions} (stepOne, stepTwo)")
    print(f"  Actual:   {actual_actions}")
    if actual_actions == expected_actions:
        print("  ✓ PASS: Nested actions extracted correctly")
    else:
        print("  ✗ FAIL: Nested actions not extracted")
    print()
    
    # Summary
    if actual_inputs == expected_inputs and actual_outputs == expected_outputs and actual_actions == expected_actions:
        print("✓ Issue 2: FIXED - All extraction working!")
    else:
        print("✗ Issue 2: PRESENT - Extraction not working")
        
except Exception as e:
    print(f"✗ UNEXPECTED ERROR: {e}")
    import traceback
    traceback.print_exc()

print()
print("=" * 70)
print("Summary")
print("=" * 70)
print()
print("These tests demonstrate two bugs in sysml2py 0.6.0:")
print()
print("1. State machines with transitions crash on load")
print("   Error: 'BehaviorUsageMember' missing 'get_definition()'")
print()
print("2. Activity parameters and nested actions not extracted")
print("   action.action_inputs, action.action_outputs, action.actions all return []")
print()
print("For more details, see: BUG_REPORT_FOR_SYSML2PY.md")
